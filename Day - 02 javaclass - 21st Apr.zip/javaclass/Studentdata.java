package javaclass;

public class Studentdata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=11;
		String b="Rahul";
		int eng=50;
		int maths=55;
		int sci=60;
		int hin=45;
		int sst=70;
		
		int total = eng+maths+sci+hin+sst;
		int avg =total/5;
		System.out.println(total/5);
		System.out.println("total marks obtained by rahul" + " "+ "="+""+total);
		System.out.println("roll number" + a);
		
		System.out.println(total);
				
	}

}
