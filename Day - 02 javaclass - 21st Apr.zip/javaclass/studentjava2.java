package javaclass;

public class studentjava2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=1;
		int b=2;
		int c=3;
		int d=4;
		
		int e=a*a*a;
		int f=b*b*b;
		int g=c*c*c;
		int h=d*d*d;
		
		if (e+f+g==h)
			System.out.println("satisfied");
		else 
			System.out.println("not satisfied");
		
		
	
	}

}
