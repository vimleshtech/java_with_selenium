package example;

public class Multiply {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=1;
		int y=2;
		int z=3;
		
		int a =x*y*z;
		System.out.println(a);
		
		
		int  b;
		a =550;
		b =67;
		//show greater no
		if(a>b)
		{
			System.out.println("a is greater");
		}
		else
		{
			System.out.println("b is greater ");
		}
		
		
	}

}

